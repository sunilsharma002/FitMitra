package com.fitmitra.service;

import com.fitmitra.model.Workout;
import com.fitmitra.repository.WorkoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class WorkoutService {
    
    @Autowired
    private WorkoutRepository workoutRepository;
    
    public List<Workout> getWorkoutsByUserId(Long userId) {
        return workoutRepository.findByUserIdOrderByDayOfWeekAscExerciseNameAsc(userId);
    }
    
    public Workout saveWorkout(Workout workout) {
        if (workout.getCreatedAt() == null) {
            workout.setCreatedAt(LocalDateTime.now());
        }
        return workoutRepository.save(workout);
    }
    
    public void deleteWorkout(Long workoutId) {
        workoutRepository.deleteById(workoutId);
    }
    
    public Long countDistinctDays(Long userId) {
        return workoutRepository.countDistinctDaysByUserId(userId);
    }
    
    public List<Workout> getAllWorkouts(Long userId) {
        return workoutRepository.findByUserId(userId);
    }
} 