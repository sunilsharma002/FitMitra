package com.fitmitra.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.context.ApplicationContext;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import com.fitmitra.ui.ChatBot;

@Component
public class DashboardFrame extends JFrame {
    private JPanel mainPanel;
    private JPanel contentPanel;
    private Long currentUserId;
    private String currentUsername;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private ApplicationContext applicationContext;
    
    @Autowired
    private WorkoutFrame workoutFrame;
    
    @Autowired
    private NutritionFrame nutritionFrame;
    
    @Autowired
    private GoalsFrame goalsFrame;
    
    @Autowired
    private ProfileFrame profileFrame;
    
    private JPanel dashboardPanelRef;
    private JPanel mainContentPanelRef;
    private JPanel dailyTrackingPanelRef;
    private JPanel trackingCardsPanelRef;
    private JLabel welcomeLabelRef;
    private JLabel waterValueLabelRef;
    private JLabel caloriesValueLabelRef;
    private JLabel stepsValueLabelRef;
    
    // Add static targets at the top of the class
    private static final int WATER_TARGET = 3000; // ml
    private static final int CALORIES_TARGET = 2200; // kcal
    private static final int STEPS_TARGET = 10000; // steps
    
    // Add at the top of the class
    private JTable routineTable;
    private JLabel liveReminderLabel;
    private static final String[][] DAILY_ROUTINE = {
        {"7:30 AM", "Breakfast"},
        {"9:00 AM", "Drink Water"},
        {"10:30 AM", "Snack"},
        {"12:30 PM", "Lunch"},
        {"2:00 PM", "Drink Water"},
        {"4:00 PM", "Snack"},
        {"6:00 PM", "Drink Water"},
        {"8:00 PM", "Dinner"},
        {"9:30 PM", "Drink Water"}
    };
    private static final String[] ROUTINE_COLUMNS = {"Time", "Activity"};
    
    // Add a user-friendly error label at the top of the class
    private JLabel errorLabel;
    
    // Add stat label fields at the top of the class
    private JLabel weightStatLabel;
    private JLabel bmiStatLabel;
    private JLabel fitnessGoalStatLabel;
    private JLabel workoutConsistencyStatLabel;
    private JLabel topExerciseStatLabel;
    private JLabel totalExercisesStatLabel;
    
    // At the top of the class, add:
    private JLabel topWelcomeLabel;
    
    public DashboardFrame() {
        setTitle("FitMitra - Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Initialize main panel
        mainPanel = new JPanel(new BorderLayout());
        
        // Initialize content panel
        contentPanel = new JPanel(new CardLayout());
        
        // Create and add dashboard panel first
        JPanel dashboardPanel = createDashboardPanel();
        contentPanel.add(dashboardPanel, "dashboard");
        
        // Create and add other panels
        JPanel workoutsPanel = new JPanel(new BorderLayout());
        JPanel mealsPanel = new JPanel(new BorderLayout());
        JPanel goalsPanel = new JPanel(new BorderLayout());
        JPanel profilePanel = new JPanel(new BorderLayout());
        
        contentPanel.add(workoutsPanel, "workouts");
        contentPanel.add(mealsPanel, "meals");
        contentPanel.add(profilePanel, "profile");
        contentPanel.add(goalsPanel, "goals");

        
        // Create and add sidebar
        JPanel sidebar = createSidebar();
        mainPanel.add(sidebar, BorderLayout.WEST);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Add main panel to frame
        add(mainPanel);
    }
    
    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(0, 150, 136));
        sidebar.setPreferredSize(new Dimension(250, getHeight()));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Add logo
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        logoPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("FitMitra");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        logoPanel.add(titleLabel);
        sidebar.add(logoPanel);
        
        // Add welcome message
        JLabel topWelcomeLabel = new JLabel("Welcome, " + (currentUsername != null ? currentUsername : "User") + "!");
        topWelcomeLabel.setForeground(Color.WHITE);
        topWelcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        topWelcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(topWelcomeLabel);
        
        sidebar.add(Box.createRigidArea(new Dimension(0, 30)));
        
        JButton dashboardButton = createSidebarButton("Dashboard");
        dashboardButton.addActionListener(e -> showPanel("dashboard"));
        sidebar.add(dashboardButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));
        
        JButton workoutsButton = createSidebarButton("Workouts");
        workoutsButton.addActionListener(e -> {
            workoutFrame.setUserId(currentUserId);
            showPanel("workouts");
        });
        sidebar.add(workoutsButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));
        
        JButton mealsButton = createSidebarButton("Meals");
        mealsButton.addActionListener(e -> {
            nutritionFrame.setUserId(currentUserId);
            showPanel("meals");
        });
        sidebar.add(mealsButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));
        
        JButton goalsButton = createSidebarButton("Goals");
        goalsButton.addActionListener(e -> {
            goalsFrame.setUserId(currentUserId);
            showPanel("goals");
        });
        sidebar.add(goalsButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton chatBotButton = createSidebarButton("Your Friend");
        chatBotButton.addActionListener(e -> {
            ChatBot chatBot = new ChatBot();
            chatBot.setVisible(true);
            chatBot.setLocationRelativeTo(null);
        });
        
        JButton profileButton = createSidebarButton("Profile");
        profileButton.addActionListener(e -> {
            profileFrame.setUserId(currentUserId);
            showPanel("profile");
        });
        sidebar.add(chatBotButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));
        sidebar.add(profileButton);

        // Add 'Your Friend' button only to dashboard

        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));

        
        sidebar.add(Box.createVerticalGlue());


        JButton logoutButton = createSidebarButton("Logout");
        logoutButton.addActionListener(e -> handleLogout());
        sidebar.add(logoutButton);
        
        return sidebar;
    }
    
    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(0.0f);
        button.setMaximumSize(new Dimension(200, 50));
        button.setPreferredSize(new Dimension(200, 50));
        button.setBackground(new Color(0, 180, 166));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 200, 186));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 180, 166));
            }
        });
        
        return button;
    }
    
    private JPanel createDashboardPanel() {
        JPanel dashboardPanel = new JPanel(new BorderLayout());
        dashboardPanelRef = dashboardPanel;
        dashboardPanel.setBackground(Color.WHITE);
        
        // Create main content panel with three sections
        JPanel mainContentPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        mainContentPanelRef = mainContentPanel;
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Left panel for stats
        JPanel statsPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        statsPanel.setBackground(Color.WHITE);
        
        try {
            System.out.println("Fetching data for user ID: " + currentUserId);
            
            // Get user stats
            String userStatsQuery = "SELECT weight, height, fitness_aim, created_at FROM users WHERE id = ?";
            Map<String, Object> userStats = jdbcTemplate.queryForMap(userStatsQuery, currentUserId);
            System.out.println("User stats fetched: " + userStats);
            
            // Calculate BMI
            double weight = (Double) userStats.get("weight");
            double height = (Double) userStats.get("height");
            double bmi = weight / ((height/100) * (height/100));
            
            // Get workout statistics
            String workoutStatsQuery = "SELECT COUNT(DISTINCT day_of_week) as days_per_week, " +
                                     "COUNT(*) as total_exercises, " +
                                     "SUM(sets * reps) as total_reps " +
                                     "FROM workouts WHERE user_id = ?";
            Map<String, Object> workoutStats = jdbcTemplate.queryForMap(workoutStatsQuery, currentUserId);
            System.out.println("Workout stats fetched: " + workoutStats);
            
            // Add stat cards with dynamic content
            weightStatLabel = new JLabel("N/A");
            JPanel weightCard = createStatCard("Current Weight", weightStatLabel);
            addProgressIndicator(weightCard, "Weight Progress", weight, (Double)userStats.get("weight"));
            statsPanel.add(weightCard);
            
            bmiStatLabel = new JLabel("N/A");
            JPanel bmiCard = createStatCard("BMI", bmiStatLabel);
            addBMICategory(bmiCard, bmi);
            statsPanel.add(bmiCard);
            
            workoutConsistencyStatLabel = new JLabel("N/A");
            JPanel workoutCard = createStatCard("Workout Consistency", workoutConsistencyStatLabel);
            addWorkoutDetails(workoutCard, workoutStats);
            statsPanel.add(workoutCard);
            
            // Get most frequent exercise
            String mostFrequentExerciseQuery = "SELECT exercise_name, COUNT(*) as count " +
                                             "FROM workouts WHERE user_id = ? " +
                                             "GROUP BY exercise_name ORDER BY count DESC LIMIT 1";
            Map<String, Object> mostFrequentExercise = jdbcTemplate.queryForMap(mostFrequentExerciseQuery, currentUserId);
            System.out.println("Most frequent exercise: " + mostFrequentExercise);
            
            topExerciseStatLabel = new JLabel("N/A");
            JPanel topExerciseCard = createStatCard("Top Exercise", topExerciseStatLabel);
            addExerciseDetails(topExerciseCard, mostFrequentExercise);
            statsPanel.add(topExerciseCard);
            
            fitnessGoalStatLabel = new JLabel("N/A");
            JPanel fitnessCard = createStatCard("Fitness Goal", fitnessGoalStatLabel);
            addGoalProgress(fitnessCard, userStats.get("fitness_aim").toString());
            statsPanel.add(fitnessCard);
            
            totalExercisesStatLabel = new JLabel("N/A");
            JPanel totalExercisesCard = createStatCard("Total Exercises", totalExercisesStatLabel);
            addTotalReps(totalExercisesCard, workoutStats);
            statsPanel.add(totalExercisesCard);
            
        } catch (Exception e) {
            System.err.println("Error fetching user stats: " + e.getMessage());
            e.printStackTrace();
            // If there's any error, show default stats
            weightStatLabel = new JLabel("N/A");
            JPanel weightCard = createStatCard("Current Weight", weightStatLabel);
            statsPanel.add(weightCard);
            bmiStatLabel = new JLabel("N/A");
            JPanel bmiCard = createStatCard("BMI", bmiStatLabel);
            statsPanel.add(bmiCard);
            workoutConsistencyStatLabel = new JLabel("N/A");
            JPanel workoutCard = createStatCard("Workout Consistency", workoutConsistencyStatLabel);
            statsPanel.add(workoutCard);
            topExerciseStatLabel = new JLabel("N/A");
            JPanel topExerciseCard = createStatCard("Top Exercise", topExerciseStatLabel);
            statsPanel.add(topExerciseCard);
            fitnessGoalStatLabel = new JLabel("N/A");
            JPanel fitnessCard = createStatCard("Fitness Goal", fitnessGoalStatLabel);
            statsPanel.add(fitnessCard);
            totalExercisesStatLabel = new JLabel("N/A");
            JPanel totalExercisesCard = createStatCard("Total Exercises", totalExercisesStatLabel);
            statsPanel.add(totalExercisesCard);
        }
        
        // Middle panel for daily tracking
        JPanel dailyTrackingPanel = new JPanel(new BorderLayout());
        dailyTrackingPanelRef = dailyTrackingPanel;
        dailyTrackingPanel.setBackground(Color.WHITE);
        dailyTrackingPanel.setBorder(BorderFactory.createTitledBorder("Daily Tracking"));
        
        JPanel trackingCardsPanel = new JPanel(new GridLayout(3, 1, 20, 20));
        trackingCardsPanelRef = trackingCardsPanel;
        trackingCardsPanel.setBackground(Color.WHITE);
        trackingCardsPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        try {
            System.out.println("Fetching daily tracking data for user ID: " + currentUserId);
            // Get today's tracking data
            String trackingQuery = "SELECT water_intake_ml, calories_consumed, steps_count " +
                                 "FROM daily_tracking WHERE user_id = ? AND date = CURRENT_DATE";
            Map<String, Object> trackingData = jdbcTemplate.queryForMap(trackingQuery, currentUserId);
            System.out.println("Daily tracking data fetched: " + trackingData);
            
            // Water intake card
            waterValueLabelRef = new JLabel(String.format("%d ml / %d ml", trackingData.get("water_intake_ml"), WATER_TARGET));
            JPanel waterCard = createTrackingCard("Water Intake", waterValueLabelRef, "Update Water Intake", evt -> updateWaterIntake());
            trackingCardsPanel.add(waterCard);
            
            // Calories card
            caloriesValueLabelRef = new JLabel(String.format("%d kcal / %d kcal", trackingData.get("calories_consumed"), CALORIES_TARGET));
            JPanel caloriesCard = createTrackingCard("Calories", caloriesValueLabelRef, "Update Calories", evt -> updateCalories());
            trackingCardsPanel.add(caloriesCard);
            
            // Steps card
            stepsValueLabelRef = new JLabel(String.format("%d / %d", trackingData.get("steps_count"), STEPS_TARGET));
            JPanel stepsCard = createTrackingCard("Steps", stepsValueLabelRef, "Update Steps", evt -> updateSteps());
            trackingCardsPanel.add(stepsCard);
            
        } catch (Exception e) {
            System.err.println("Error fetching daily tracking data: " + e.getMessage());
            e.printStackTrace();
            // If no data exists, show 0/target
            waterValueLabelRef = new JLabel(String.format("0 ml / %d ml", WATER_TARGET));
            JPanel waterCard = createTrackingCard("Water Intake", waterValueLabelRef, "Update Water Intake", evt -> updateWaterIntake());
            trackingCardsPanel.add(waterCard);
            caloriesValueLabelRef = new JLabel(String.format("0 kcal / %d kcal", CALORIES_TARGET));
            JPanel caloriesCard = createTrackingCard("Calories", caloriesValueLabelRef, "Update Calories", evt -> updateCalories());
            trackingCardsPanel.add(caloriesCard);
            stepsValueLabelRef = new JLabel(String.format("0 / %d", STEPS_TARGET));
            JPanel stepsCard = createTrackingCard("Steps", stepsValueLabelRef, "Update Steps", evt -> updateSteps());
            trackingCardsPanel.add(stepsCard);
        }
        
        dailyTrackingPanel.add(trackingCardsPanel, BorderLayout.CENTER);
        
        // Right panel for meal time reminder
        JPanel mealTimePanel = new JPanel(new BorderLayout());
        mealTimePanel.setBackground(Color.WHITE);
        mealTimePanel.setBorder(BorderFactory.createTitledBorder("Meal Reminder"));
    // change here
        String message = getMealTimeMessage();
        JLabel mealTimeLabel = new JLabel("<html><div style='text-align:center; width:200px;'>" + message + "</div></html>");
        mealTimeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        mealTimeLabel.setForeground(new Color(0, 150, 136));
        mealTimeLabel.setHorizontalAlignment(SwingConstants.CENTER);


        mealTimeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        mealTimeLabel.setForeground(new Color(0, 150, 136));
        mealTimePanel.add(mealTimeLabel, BorderLayout.CENTER);
        
        // Add all panels to main content
        mainContentPanel.add(statsPanel);
        mainContentPanel.add(dailyTrackingPanel);
        mainContentPanel.add(mealTimePanel);
        
        // In createDashboardPanel, after mainContentPanel is created, add a new panel for routine and reminder
        JPanel routinePanel = new JPanel(new BorderLayout());
        routinePanel.setBackground(Color.WHITE);
        routinePanel.setBorder(BorderFactory.createTitledBorder("Today's Routine"));
        routinePanel.setPreferredSize(new Dimension(400, 200));
        
        routineTable = new JTable(DAILY_ROUTINE, ROUTINE_COLUMNS);
        routineTable.setEnabled(false);
        routineTable.setFont(new Font("Arial", Font.PLAIN, 12));
        routineTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        routineTable.setRowHeight(18);
        routineTable.setPreferredScrollableViewportSize(new Dimension(380, 150));
        JScrollPane routineScroll = new JScrollPane(routineTable);
        routineScroll.setPreferredSize(new Dimension(380, 150));
        routinePanel.add(routineScroll, BorderLayout.CENTER);
        
        // Live reminder panel
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.setBackground(Color.WHITE);
        reminderPanel.setBorder(BorderFactory.createTitledBorder("Current Reminder"));
        reminderPanel.setPreferredSize(new Dimension(400, 200));
        
        // Create a panel for the reminder message with proper padding and alignment
        JPanel reminderContentPanel = new JPanel(new BorderLayout());
        reminderContentPanel.setBackground(Color.WHITE);
        reminderContentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        liveReminderLabel = new JLabel(getLiveReminderMessage(), SwingConstants.CENTER);
        liveReminderLabel.setFont(new Font("Arial", Font.BOLD, 18));
        liveReminderLabel.setForeground(new Color(0, 150, 136));
        liveReminderLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Wrap the text in HTML to enable text wrapping, but do not set a fixed width
        liveReminderLabel.setText("<html><div style='text-align:center;'>" + getLiveReminderMessage() + "</div></html>");
        liveReminderLabel.setHorizontalAlignment(SwingConstants.CENTER);
        liveReminderLabel.setPreferredSize(new Dimension(350, 60));
        liveReminderLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        reminderContentPanel.add(liveReminderLabel, BorderLayout.CENTER);
        reminderPanel.add(reminderContentPanel, BorderLayout.CENTER);
        
        // Add routinePanel and reminderPanel below the mainContentPanel
        JPanel bottomPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        bottomPanel.setPreferredSize(new Dimension(1200, 220));
        
        // Create container panels to ensure consistent sizing
        JPanel routineContainer = new JPanel(new BorderLayout());
        routineContainer.setBackground(Color.WHITE);
        routineContainer.add(routinePanel, BorderLayout.CENTER);
        
        JPanel reminderContainer = new JPanel(new BorderLayout());
        reminderContainer.setBackground(Color.WHITE);
        reminderContainer.add(reminderPanel, BorderLayout.CENTER);
        
        bottomPanel.add(routineContainer);
        bottomPanel.add(reminderContainer);
        
        // Add bottomPanel to the dashboardPanel (below mainContentPanel)
        dashboardPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        dashboardPanel.add(mainContentPanel, BorderLayout.CENTER);
        
        // Add a top panel with the welcome message aligned right
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        JLabel topWelcomeLabel = new JLabel("Welcome, " + (currentUsername != null ? currentUsername : "User") + "!");
        topWelcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        topWelcomeLabel.setForeground(new Color(0, 150, 136));
        topWelcomeLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        topPanel.add(topWelcomeLabel, BorderLayout.EAST);
        dashboardPanel.add(topPanel, BorderLayout.NORTH);
        // Store a reference to update after login
        this.topWelcomeLabel = topWelcomeLabel;
        
        return dashboardPanel;
    }
    
    private JPanel createStatCard(String title, JLabel valueLabel) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(new Color(240, 240, 240));
        card.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        
        valueLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        valueLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private void showPanel(String panelName) {
        CardLayout cl = (CardLayout)(contentPanel.getLayout());
        cl.show(contentPanel, panelName);
        
        // Show the appropriate frame
        if (panelName.equals("workouts") && workoutFrame != null) {
            workoutFrame.setUserId(currentUserId);
            workoutFrame.setVisible(true);
            workoutFrame.setLocationRelativeTo(null);
        } else if (panelName.equals("meals") && nutritionFrame != null) {
            nutritionFrame.setUserId(currentUserId);
            nutritionFrame.setVisible(true);
            nutritionFrame.setLocationRelativeTo(null);
        } else if (panelName.equals("goals") && goalsFrame != null) {
            goalsFrame.setUserId(currentUserId);
            goalsFrame.setVisible(true);
            goalsFrame.setLocationRelativeTo(null);
        } else if (panelName.equals("profile") && profileFrame != null) {
            profileFrame.setUserId(currentUserId);
            profileFrame.setVisible(true);
            profileFrame.setLocationRelativeTo(null);
        }
    }
    
    private void handleLogout() {
        this.setVisible(false);
        LoginFrame loginFrame = applicationContext.getBean(LoginFrame.class);
        loginFrame.clearFields();
        loginFrame.setVisible(true);
    }
    
    public void setCurrentUser(Long userId, String username) {
        this.currentUserId = userId;
        this.currentUsername = username;
        if (topWelcomeLabel != null) {
            topWelcomeLabel.setText("Welcome, " + username + "!");
        }
    }
    
    public void updateDashboard() {
        if (currentUserId == null) {
            if (errorLabel != null) {
                errorLabel.setText("Error: No user is logged in. Please log in again.");
                errorLabel.setVisible(true);
            }
            System.err.println("[Dashboard] currentUserId is null. Cannot update dashboard.");
            return;
        }
        try {
            if (errorLabel != null) {
                errorLabel.setText("");
                errorLabel.setVisible(false);
            }
            System.out.println("[Dashboard] Updating dashboard for user ID: " + currentUserId);
            if (topWelcomeLabel != null) {
                topWelcomeLabel.setText("Welcome, " + currentUsername + "!");
            }
            // Fetch user stats
            String userStatsQuery = "SELECT weight, height, fitness_aim, created_at FROM users WHERE id = ?";
            Map<String, Object> userStats = jdbcTemplate.queryForMap(userStatsQuery, currentUserId);
            System.out.println("[Dashboard] User stats: " + userStats);
            // Fetch daily tracking
            String trackingQuery = "SELECT water_intake_ml, calories_consumed, steps_count FROM daily_tracking WHERE user_id = ? AND date = CURRENT_DATE";
            Map<String, Object> trackingData;
            try {
                trackingData = jdbcTemplate.queryForMap(trackingQuery, currentUserId);
            } catch (Exception e) {
                trackingData = Map.of(
                    "water_intake_ml", 0,
                    "calories_consumed", 0,
                    "steps_count", 0
                );
            }
            System.out.println("[Dashboard] Tracking data: " + trackingData);
            // Fetch workout stats
            String workoutStatsQuery = "SELECT COUNT(DISTINCT day_of_week) as days_per_week, COUNT(*) as total_exercises, SUM(sets * reps) as total_reps FROM workouts WHERE user_id = ?";
            Map<String, Object> workoutStats = jdbcTemplate.queryForMap(workoutStatsQuery, currentUserId);
            // Fetch most frequent exercise
            String mostFrequentExerciseQuery = "SELECT exercise_name, COUNT(*) as count FROM workouts WHERE user_id = ? GROUP BY exercise_name ORDER BY count DESC LIMIT 1";
            Map<String, Object> mostFrequentExercise;
            try {
                mostFrequentExercise = jdbcTemplate.queryForMap(mostFrequentExerciseQuery, currentUserId);
            } catch (Exception e) {
                mostFrequentExercise = Map.of("exercise_name", "N/A", "count", 0);
            }
            // Fetch active goal
            String activeGoalQuery = "SELECT name FROM goals WHERE user_id = ? AND status = 'IN_PROGRESS' ORDER BY start_date DESC LIMIT 1";
            String activeGoal;
            try {
                activeGoal = jdbcTemplate.queryForObject(activeGoalQuery, String.class, currentUserId);
                if (activeGoal == null) {
                    activeGoal = "No active goal";
                }
            } catch (Exception e) {
                activeGoal = "No active goal";
            }
            // Update stat cards
            if (weightStatLabel != null) weightStatLabel.setText(String.format("%.1f kg", userStats.get("weight")));
            if (bmiStatLabel != null) {
                double weight = ((Number)userStats.get("weight")).doubleValue();
                double height = ((Number)userStats.get("height")).doubleValue();
                double bmi = weight / ((height/100) * (height/100));
                bmiStatLabel.setText(String.format("%.1f", bmi));
            }
            if (fitnessGoalStatLabel != null) fitnessGoalStatLabel.setText(activeGoal);
            if (workoutConsistencyStatLabel != null) workoutConsistencyStatLabel.setText(workoutStats.get("days_per_week") + " days/week");
            if (topExerciseStatLabel != null) topExerciseStatLabel.setText(mostFrequentExercise.get("exercise_name").toString());
            if (totalExercisesStatLabel != null) totalExercisesStatLabel.setText(workoutStats.get("total_exercises").toString());
            // Update tracking cards
            if (waterValueLabelRef != null) waterValueLabelRef.setText(String.format("%d ml / %d ml", trackingData.get("water_intake_ml"), WATER_TARGET));
            if (caloriesValueLabelRef != null) caloriesValueLabelRef.setText(String.format("%d kcal / %d kcal", trackingData.get("calories_consumed"), CALORIES_TARGET));
            if (stepsValueLabelRef != null) stepsValueLabelRef.setText(String.format("%d / %d", trackingData.get("steps_count"), STEPS_TARGET));
            if (liveReminderLabel != null) liveReminderLabel.setText(getLiveReminderMessage());
            revalidate();
            repaint();
        } catch (Exception e) {
            if (errorLabel != null) {
                errorLabel.setText("Error loading dashboard data: " + e.getMessage());
                errorLabel.setVisible(true);
            }
            System.err.println("[Dashboard] Error updating dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void addProgressIndicator(JPanel card, String title, double currentValue, double previousValue) {
        JPanel indicatorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        indicatorPanel.setBackground(new Color(240, 240, 240));
        
        double change = currentValue - previousValue;
        String arrow = change > 0 ? "↑" : (change < 0 ? "↓" : "→");
        Color color = change > 0 ? new Color(0, 150, 0) : (change < 0 ? new Color(150, 0, 0) : Color.GRAY);
        
        JLabel indicator = new JLabel(String.format("%s %.1f kg", arrow, Math.abs(change)));
        indicator.setForeground(color);
        indicator.setFont(new Font("Arial", Font.BOLD, 12));
        indicatorPanel.add(indicator);
        
        card.add(indicatorPanel, BorderLayout.SOUTH);
    }
    
    private void addBMICategory(JPanel card, double bmi) {
        JPanel categoryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        categoryPanel.setBackground(new Color(240, 240, 240));
        
        String category;
        Color color;
        if (bmi < 18.5) {
            category = "Underweight";
            color = new Color(150, 0, 0);
        } else if (bmi < 25) {
            category = "Normal";
            color = new Color(0, 150, 0);
        } else if (bmi < 30) {
            category = "Overweight";
            color = new Color(150, 150, 0);
        } else {
            category = "Obese";
            color = new Color(150, 0, 0);
        }
        
        JLabel categoryLabel = new JLabel(category);
        categoryLabel.setForeground(color);
        categoryLabel.setFont(new Font("Arial", Font.BOLD, 12));
        categoryPanel.add(categoryLabel);
        
        card.add(categoryPanel, BorderLayout.SOUTH);
    }
    
    private void addWorkoutDetails(JPanel card, Map<String, Object> stats) {
        JPanel detailsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        detailsPanel.setBackground(new Color(240, 240, 240));
        
        JLabel detailsLabel = new JLabel(String.format("Total: %d exercises", stats.get("total_exercises")));
        detailsLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        detailsPanel.add(detailsLabel);
        
        card.add(detailsPanel, BorderLayout.SOUTH);
    }
    
    private void addExerciseDetails(JPanel card, Map<String, Object> exercise) {
        JPanel detailsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        detailsPanel.setBackground(new Color(240, 240, 240));
        
        JLabel detailsLabel = new JLabel(String.format("Count: %d times", exercise.get("count")));
        detailsLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        detailsPanel.add(detailsLabel);
        
        card.add(detailsPanel, BorderLayout.SOUTH);
    }
    
    private void addGoalProgress(JPanel card, String fitnessAim) {
        JPanel progressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        progressPanel.setBackground(new Color(240, 240, 240));
        
        JLabel progressLabel = new JLabel("Track your progress");
        progressLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        progressPanel.add(progressLabel);
        
        card.add(progressPanel, BorderLayout.SOUTH);
    }
    
    private void addTotalReps(JPanel card, Map<String, Object> stats) {
        JPanel repsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        repsPanel.setBackground(new Color(240, 240, 240));
        
        JLabel repsLabel = new JLabel(String.format("Total reps: %d", stats.get("total_reps")));
        repsLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        repsPanel.add(repsLabel);
        
        card.add(repsPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createTrackingCard(String title, JLabel valueLabel, String buttonText, ActionListener listener) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(new Color(240, 240, 240));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        card.setPreferredSize(new Dimension(280, 100));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 2, 5));

        valueLabel.setFont(new Font("Arial", Font.BOLD, 28));
        valueLabel.setForeground(new Color(0, 150, 136));
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        valueLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 10, 5));

        JButton updateButton = new JButton(buttonText);
        updateButton.setFont(new Font("Arial", Font.PLAIN, 14));
        updateButton.setPreferredSize(new Dimension(140, 32));
        updateButton.addActionListener(listener);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.add(updateButton);

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(buttonPanel, BorderLayout.SOUTH);
        return card;
    }
    
    private void updateWaterIntake() {
        String input = JOptionPane.showInputDialog(this, 
            "Enter water intake in ml:", 
            "Update Water Intake",
            JOptionPane.QUESTION_MESSAGE);
            
        if (input != null && !input.trim().isEmpty()) {
            try {
                int waterIntake = Integer.parseInt(input);
                updateDailyTracking("water_intake_ml", waterIntake);
                updateDashboard();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a valid number",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void updateCalories() {
        String input = JOptionPane.showInputDialog(this, 
            "Enter calories consumed:", 
            "Update Calories",
            JOptionPane.QUESTION_MESSAGE);
            
        if (input != null && !input.trim().isEmpty()) {
            try {
                int calories = Integer.parseInt(input);
                updateDailyTracking("calories_consumed", calories);
                updateDashboard();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a valid number",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void updateSteps() {
        String input = JOptionPane.showInputDialog(this, 
            "Enter number of steps:", 
            "Update Steps",
            JOptionPane.QUESTION_MESSAGE);
            
        if (input != null && !input.trim().isEmpty()) {
            try {
                int steps = Integer.parseInt(input);
                updateDailyTracking("steps_count", steps);
                updateDashboard();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a valid number",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void updateDailyTracking(String column, int value) {
        try {
            System.out.println("Updating " + column + " to " + value + " for user ID: " + currentUserId);
            
            // First check if record exists for today
            String checkQuery = "SELECT COUNT(*) FROM daily_tracking WHERE user_id = ? AND date = CURRENT_DATE";
            int count = jdbcTemplate.queryForObject(checkQuery, Integer.class, currentUserId);
            System.out.println("Existing records for today: " + count);
                       
            String updateQuery;
            if (count == 0) {
                // Insert new record
                updateQuery = "INSERT INTO daily_tracking (user_id, date, " + column + ") VALUES (?, CURRENT_DATE, ?)";
                jdbcTemplate.update(updateQuery, currentUserId, value);
                System.out.println("Inserted new record");
            } else {
                // Update existing record
                updateQuery = "UPDATE daily_tracking SET " + column + " = ? WHERE user_id = ? AND date = CURRENT_DATE";
                jdbcTemplate.update(updateQuery, value, currentUserId);
                System.out.println("Updated existing record");
            }
            
            // Verify the update
            String verifyQuery = "SELECT " + column + " FROM daily_tracking WHERE user_id = ? AND date = CURRENT_DATE";
            int updatedValue = jdbcTemplate.queryForObject(verifyQuery, Integer.class, currentUserId);
            System.out.println("Verified " + column + " updated to: " + updatedValue);
            
            // Force refresh the dashboard
            SwingUtilities.invokeLater(() -> {
                updateDashboard();
                revalidate();
                repaint();
            });
            
        } catch (Exception e) {
            System.err.println("Error updating daily tracking: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error updating data: " + e.getMessage(),
                "Update Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Add a helper method for meal time message
    private String getMealTimeMessage() {
        java.time.LocalTime now = java.time.LocalTime.now();
        if (now.isAfter(java.time.LocalTime.of(7, 0)) && now.isBefore(java.time.LocalTime.of(10, 0))) {
            return "It's time for breakfast!";
        } else if (now.isAfter(java.time.LocalTime.of(12, 0)) && now.isBefore(java.time.LocalTime.of(14, 0))) {
            return "It's time for lunch!";
        } else if (now.isAfter(java.time.LocalTime.of(19, 0)) && now.isBefore(java.time.LocalTime.of(21, 0))) {
            return "It's time for dinner!";
        } else if (now.isAfter(java.time.LocalTime.of(8, 30)) && now.isBefore(java.time.LocalTime.of(9, 30))) {
            return "Drink a glass of water!";
        } else if (now.isAfter(java.time.LocalTime.of(13, 30)) && now.isBefore(java.time.LocalTime.of(14, 30))) {
            return "Drink a glass of water!";
        } else if (now.isAfter(java.time.LocalTime.of(17, 30)) && now.isBefore(java.time.LocalTime.of(18, 30))) {
            return "Drink a glass of water!";
        } else if (now.isAfter(java.time.LocalTime.of(21, 0)) && now.isBefore(java.time.LocalTime.of(22, 0))) {
            return "Drink a glass of water!";
        } else if (now.isAfter(java.time.LocalTime.of(10, 0)) && now.isBefore(java.time.LocalTime.of(11, 0))) {
            return "It's time for a snack!";
        } else if (now.isAfter(java.time.LocalTime.of(15, 30)) && now.isBefore(java.time.LocalTime.of(16, 30))) {
            return "It's time for a snack!";
        } else {
            return "No meal or drink scheduled right now. Stay hydrated! 💧";
        }
    }
    
    // Add a helper method for live reminder
    private String getLiveReminderMessage() {
        java.time.LocalTime now = java.time.LocalTime.now();
        if (now.isAfter(java.time.LocalTime.of(6, 0)) && now.isBefore(java.time.LocalTime.of(8, 0))) {
            return "Morning workout time! Start your day with energy! 💪";
        } else if (now.isAfter(java.time.LocalTime.of(12, 0)) && now.isBefore(java.time.LocalTime.of(13, 0))) {
            return "Take a short walk after lunch! 🚶‍♂️";
        } else if (now.isAfter(java.time.LocalTime.of(17, 0)) && now.isBefore(java.time.LocalTime.of(19, 0))) {
            return "Evening workout time! Keep pushing! 💪";
        } else if (now.isAfter(java.time.LocalTime.of(20, 0)) && now.isBefore(java.time.LocalTime.of(21, 0))) {
            return "Time for some stretching! Stay flexible! 🧘‍♂️";
        } else if (now.isAfter(java.time.LocalTime.of(22, 0)) && now.isBefore(java.time.LocalTime.of(23, 0))) {
            return "Get ready for bed! Rest is important for recovery! 😴";
        } else {
            return "Stay active and keep moving! Every step counts! 🚶‍♂️";
        }
    }
} 