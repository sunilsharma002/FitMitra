package com.fitmitra.repository;

import com.fitmitra.model.DailyTracking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DailyTrackingRepository extends JpaRepository<DailyTracking, Long> {
    Optional<DailyTracking> findByUserIdAndDate(Long userId, LocalDate date);
    List<DailyTracking> findByUserIdOrderByDateDesc(Long userId);
    List<DailyTracking> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate);
}
