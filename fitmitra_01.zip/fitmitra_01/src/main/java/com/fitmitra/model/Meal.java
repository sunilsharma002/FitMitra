package com.fitmitra.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "meals")
public class Meal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String mealType; // breakfast, lunch, dinner, snack

    @Column(nullable = false)
    private Double calories;

    @Column(nullable = false)
    private Double protein;

    @Column(nullable = false)
    private Double carbs;

    @Column(nullable = false)
    private Double fats;

    @Column
    private String ingredients;

    @Column(nullable = false)
    private Boolean isCustom = false;

    @Column
    private LocalDate consumedDate;

    @Column
    private Long userId;
} 