package com.fitmitra.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "full_name", nullable = false)
    private String fullName;
    
    @Column(nullable = false, unique = true)
    private String username;
    
    @Column(nullable = false)
    private String password;
    
    @Column(nullable = false)
    private int age;
    
    @Column(nullable = false)
    private double height;
    
    @Column(nullable = false)
    private double weight;
    
    @Column(name = "fitness_aim", nullable = false)
    private String fitnessAim;
    
    @Column(nullable = false)
    private String gender;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    public enum FitnessAim {
        MASS_GAIN("Mass Gain"),
        WEIGHT_LOSS("Weight Loss"),
        MAINTENANCE("Maintenance"),
        ENDURANCE("Endurance"),
        STRENGTH("Strength");
        
        private final String displayName;
        
        FitnessAim(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
    
    public enum Gender {
        MALE("Male"),
        FEMALE("Female");
        
        private final String displayName;
        
        Gender(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
} 