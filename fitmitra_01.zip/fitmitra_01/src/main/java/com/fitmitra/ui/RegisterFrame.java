package com.fitmitra.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.context.ApplicationContext;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

@Component
public class RegisterFrame extends JFrame {
    private JTextField fullNameField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField ageField;
    private JTextField heightField;
    private JTextField weightField;
    private JComboBox<String> fitnessAimComboBox;
    private JComboBox<String> genderComboBox;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private ApplicationContext applicationContext;
    
    public RegisterFrame() {
        setTitle("FitMitra - Register");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Create main panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(45, 45, 45);
                Color color2 = new Color(30, 30, 30);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Create logo panel
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw logo text
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 36));
                String text = "FitMitra";
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(text)) / 2;
                int y = (getHeight() + fm.getAscent()) / 2;
                g2d.drawString(text, x, y);
                
                // Draw underline
                g2d.setStroke(new BasicStroke(3));
                g2d.drawLine(x, y + 5, x + fm.stringWidth(text), y + 5);
            }
        };
        logoPanel.setPreferredSize(new Dimension(300, 150));
        logoPanel.setOpaque(false);
        
        // Create welcome message panel
        JPanel welcomePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        welcomePanel.setOpaque(false);
        JLabel welcomeLabel = new JLabel("Welcome to FitMitra - Your Personal Fitness Companion");
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomePanel.add(welcomeLabel);
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Add form fields
        addFormField(formPanel, gbc, "Full Name:", fullNameField = createStyledTextField());
        addFormField(formPanel, gbc, "Username:", usernameField = createStyledTextField());
        addFormField(formPanel, gbc, "Password:", passwordField = createStyledPasswordField());
        addFormField(formPanel, gbc, "Age:", ageField = createStyledTextField());
        addFormField(formPanel, gbc, "Height (cm):", heightField = createStyledTextField());
        addFormField(formPanel, gbc, "Weight (kg):", weightField = createStyledTextField());
        
        // Add fitness aim combo box
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel fitnessAimLabel = new JLabel("Fitness Aim:");
        fitnessAimLabel.setForeground(Color.WHITE);
        formPanel.add(fitnessAimLabel, gbc);
        
        gbc.gridx = 1;
        String[] fitnessAims = {"Weight Loss", "Muscle Gain", "Maintenance", "Endurance", "Flexibility"};
        fitnessAimComboBox = createStyledComboBox(fitnessAims);
        formPanel.add(fitnessAimComboBox, gbc);
        
        // Add gender combo box
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setForeground(Color.WHITE);
        formPanel.add(genderLabel, gbc);
        
        gbc.gridx = 1;
        String[] genders = {"Male", "Female", "Other"};
        genderComboBox = createStyledComboBox(genders);
        formPanel.add(genderComboBox, gbc);
        
        // Add register button
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton registerButton = createStyledButton("Register");
        registerButton.addActionListener(e -> handleRegistration());
        formPanel.add(registerButton, gbc);
        
        // Add back to login button
        gbc.gridy++;
        JButton backButton = createStyledButton("Back to Login");
        backButton.addActionListener(e -> goBackToLogin());
        formPanel.add(backButton, gbc);
        
        // Add panels to main panel
        mainPanel.add(logoPanel, BorderLayout.NORTH);
        mainPanel.add(welcomePanel, BorderLayout.CENTER);
        mainPanel.add(formPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private void addFormField(JPanel panel, GridBagConstraints gbc, String labelText, JComponent field) {
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.WHITE);
        panel.add(label, gbc);
        
        gbc.gridx = 1;
        panel.add(field, gbc);
    }
    
    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setBackground(new Color(60, 60, 60));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80)));
        return field;
    }
    
    private JPasswordField createStyledPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setBackground(new Color(60, 60, 60));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80)));
        return field;
    }
    
    private JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setBackground(new Color(60, 60, 60));
        comboBox.setForeground(Color.WHITE);
        comboBox.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80)));
        return comboBox;
    }
    
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 150, 136));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }
    
    private void handleRegistration() {
        try {
            String fullName = fullNameField.getText();
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            int age = Integer.parseInt(ageField.getText());
            double height = Double.parseDouble(heightField.getText());
            double weight = Double.parseDouble(weightField.getText());
            String fitnessAim = (String) fitnessAimComboBox.getSelectedItem();
            String gender = (String) genderComboBox.getSelectedItem();
            
            // Check if username already exists
            String checkSql = "SELECT COUNT(*) FROM users WHERE username = ?";
            int count = jdbcTemplate.queryForObject(checkSql, Integer.class, username);
            
            if (count > 0) {
                JOptionPane.showMessageDialog(this,
                    "Username already exists. Please choose another username.",
                    "Registration Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Hash the password
            String hashedPassword = hashPassword(password);
            
            // Insert new user
            String sql = "INSERT INTO users (full_name, username, password, age, height, weight, fitness_aim, gender) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            jdbcTemplate.update(sql, fullName, username, hashedPassword, age, height, weight, fitnessAim, gender);
            
            JOptionPane.showMessageDialog(this,
                "Registration successful! Please login with your credentials.",
                "Registration Success",
                JOptionPane.INFORMATION_MESSAGE);
            
            goBackToLogin();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Please enter valid numbers for age, height, and weight.",
                "Input Error",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error during registration: " + e.getMessage(),
                "Registration Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String hashPassword(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
    
    private void goBackToLogin() {
        this.setVisible(false);
        LoginFrame loginFrame = applicationContext.getBean(LoginFrame.class);
        loginFrame.clearFields();
        loginFrame.setVisible(true);
    }
    
    public void clearFields() {
        fullNameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        ageField.setText("");
        heightField.setText("");
        weightField.setText("");
        fitnessAimComboBox.setSelectedIndex(0);
        genderComboBox.setSelectedIndex(0);
    }
} 