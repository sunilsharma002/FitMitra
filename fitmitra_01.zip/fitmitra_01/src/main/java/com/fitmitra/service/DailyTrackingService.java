package com.fitmitra.service;

import com.fitmitra.model.DailyTracking;
import com.fitmitra.repository.DailyTrackingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DailyTrackingService {
    
    @Autowired
    private DailyTrackingRepository dailyTrackingRepository;
    
    public DailyTracking getTodayTracking(Long userId) {
        LocalDate today = LocalDate.now();
        Optional<DailyTracking> tracking = dailyTrackingRepository.findByUserIdAndDate(userId, today);
        
        if (tracking.isEmpty()) {
            DailyTracking newTracking = new DailyTracking();
            newTracking.setUserId(userId);
            newTracking.setDate(today);
            newTracking.setWaterIntakeMl(0);
            newTracking.setCaloriesConsumed(0);
            newTracking.setStepsCount(0);
            newTracking.setCreatedAt(LocalDateTime.now());
            return dailyTrackingRepository.save(newTracking);
        }
        
        return tracking.get();
    }
    
    public DailyTracking updateWaterIntake(Long userId, int waterIntakeMl) {
        DailyTracking tracking = getTodayTracking(userId);
        tracking.setWaterIntakeMl(waterIntakeMl);
        return dailyTrackingRepository.save(tracking);
    }
    
    public DailyTracking updateCalories(Long userId, int calories) {
        DailyTracking tracking = getTodayTracking(userId);
        tracking.setCaloriesConsumed(calories);
        return dailyTrackingRepository.save(tracking);
    }
    
    public DailyTracking updateSteps(Long userId, int steps) {
        DailyTracking tracking = getTodayTracking(userId);
        tracking.setStepsCount(steps);
        return dailyTrackingRepository.save(tracking);
    }
    
    public List<DailyTracking> getUserTrackingHistory(Long userId) {
        return dailyTrackingRepository.findByUserIdOrderByDateDesc(userId);
    }
    
    public List<DailyTracking> getTrackingBetweenDates(Long userId, LocalDate startDate, LocalDate endDate) {
        return dailyTrackingRepository.findByUserIdAndDateBetween(userId, startDate, endDate);
    }
}
