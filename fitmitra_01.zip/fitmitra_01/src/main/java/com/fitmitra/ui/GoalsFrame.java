package com.fitmitra.ui;

import com.fitmitra.model.Goal;
import com.fitmitra.service.GoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

@Component
public class GoalsFrame extends JFrame {
    private JTable predefinedGoalsTable;
    private JTable myGoalsTable;
    private DefaultTableModel predefinedGoalsModel;
    private DefaultTableModel myGoalsModel;
    private Long currentUserId;
    
    @Autowired
    private GoalService goalService;

    public GoalsFrame() {
        // Empty constructor for Spring
    }

    @PostConstruct
    private void init() {
        initializeUI();
    }

    public void setUserId(Long userId) {
        this.currentUserId = userId;
        loadGoals();
    }

    private void initializeUI() {
        setTitle("FitMitra - Goals Management");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // Pre-defined Goals Tab
        JPanel predefinedPanel = createPredefinedGoalsPanel();
        tabbedPane.addTab("Pre-defined Goals", predefinedPanel);

        // My Goals Tab
        JPanel myGoalsPanel = createMyGoalsPanel();
        tabbedPane.addTab("My Goals", myGoalsPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        add(mainPanel);
    }

    private JPanel createPredefinedGoalsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Table for predefined goals
        String[] columnNames = {"Name", "Description", "Target Weight", "Target Date"};
        predefinedGoalsModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        predefinedGoalsTable = new JTable(predefinedGoalsModel);
        JScrollPane tableScrollPane = new JScrollPane(predefinedGoalsTable);
        panel.add(tableScrollPane, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addToMyGoalsButton = new JButton("Add to My Goals");
        JButton backButton = new JButton("Back to Dashboard");

        addToMyGoalsButton.addActionListener(e -> addToMyGoals());
        backButton.addActionListener(e -> goBackToDashboard());

        buttonPanel.add(addToMyGoalsButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createMyGoalsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Table for user's goals
        String[] columnNames = {"Name", "Description", "Start Date", "End Date", "Status"};
        myGoalsModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        myGoalsTable = new JTable(myGoalsModel);
        JScrollPane tableScrollPane = new JScrollPane(myGoalsTable);
        panel.add(tableScrollPane, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton markCompleteButton = new JButton("Mark as Complete");
        JButton backButton = new JButton("Back to Dashboard");

        markCompleteButton.addActionListener(e -> markGoalComplete());
        backButton.addActionListener(e -> goBackToDashboard());

        buttonPanel.add(markCompleteButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadGoals() {
        // Load predefined goals
        List<Goal> predefinedGoals = goalService.getPredefinedGoals();
        updatePredefinedGoalsTable(predefinedGoals);

        // Load user's goals
        List<Goal> userGoals = goalService.getUserGoals(currentUserId);
        updateMyGoalsTable(userGoals);
    }

    private void updatePredefinedGoalsTable(List<Goal> goals) {
        predefinedGoalsModel.setRowCount(0); // Clear existing data

        for (Goal goal : goals) {
            predefinedGoalsModel.addRow(new Object[]{
                goal.getName(),
                goal.getDescription(),
                goal.getTargetWeight(),
                goal.getTargetDate()
            });
        }
    }

    private void updateMyGoalsTable(List<Goal> goals) {
        myGoalsModel.setRowCount(0); // Clear existing data

        for (Goal goal : goals) {
            myGoalsModel.addRow(new Object[]{
                goal.getName(),
                goal.getDescription(),
                goal.getStartDate(),
                goal.getEndDate(),
                goal.getStatus()
            });
        }
    }

    private void addToMyGoals() {
        int selectedRow = predefinedGoalsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Please select a goal to add",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Get the selected goal's data
            String name = (String) predefinedGoalsModel.getValueAt(selectedRow, 0);
            String description = (String) predefinedGoalsModel.getValueAt(selectedRow, 1);
            Double targetWeight = (Double) predefinedGoalsModel.getValueAt(selectedRow, 2);
            LocalDate targetDate = (LocalDate) predefinedGoalsModel.getValueAt(selectedRow, 3);

            // Create a new goal object
            Goal goal = new Goal();
            goal.setName(name);
            goal.setDescription(description);
            goal.setTargetWeight(targetWeight);
            goal.setTargetDate(targetDate);
            goal.setStartDate(LocalDate.now());
            goal.setStatus("IN_PROGRESS");

            // Add the goal to user's goals
            goalService.addGoalToUser(currentUserId, goal);

            // Show success message
            JOptionPane.showMessageDialog(this,
                "Goal added to your goals successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);

            // Refresh the goals list
            loadGoals();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error adding goal: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void markGoalComplete() {
        int selectedRow = myGoalsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Please select a goal to mark as complete",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String goalName = (String) myGoalsModel.getValueAt(selectedRow, 0);
            goalService.markGoalComplete(currentUserId, goalName);

            // Show success message
            JOptionPane.showMessageDialog(this,
                "Goal marked as complete!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);

            // Refresh the goals list
            loadGoals();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error marking goal as complete: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void goBackToDashboard() {
        this.setVisible(false);
    }
} 