package com.fitmitra.ui;

import com.fitmitra.model.Workout;
import com.fitmitra.service.WorkoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

@Component
public class WorkoutFrame extends JFrame {
    private JTable workoutTable;
    private DefaultTableModel tableModel;
    private List<Workout> workouts;
    private JTextField exerciseField, setsField, repsField;
    private JTextArea instructionsArea;
    private JComboBox<String> dayComboBox;
    private Long currentUserId;
    private JButton startButton;
    private JLabel timerLabel;
    private JLabel restTimerLabel;
    private Timer exerciseTimer;
    private Timer restTimer;
    private int seconds = 0;
    private int restSeconds = 0;
    private boolean isExerciseInProgress = false;
    private static final int REST_TIME_MINUTES = 5; // 5 minutes rest time
    private JDialog restTimerDialog;
    private JLabel popupTimerLabel;
    
    @Autowired
    private WorkoutService workoutService;

    public WorkoutFrame() {
        initializeUI();
    }

    public void setUserId(Long userId) {
        this.currentUserId = userId;
        this.workouts = workoutService.getWorkoutsByUserId(userId);
        loadWorkouts();
    }

    private void initializeUI() {
        setTitle("FitMitra - Workout Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columnNames = {"Day", "Exercise", "Sets", "Reps", "Instructions"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        workoutTable = new JTable(tableModel);
        workoutTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(workoutTable);
        tablePanel.add(tableScrollPane, BorderLayout.CENTER);
        mainPanel.add(tablePanel, BorderLayout.CENTER);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Day selection
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Day:"), gbc);
        gbc.gridx = 1;
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        dayComboBox = new JComboBox<>(days);
        formPanel.add(dayComboBox, gbc);

        // Exercise name
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Exercise:"), gbc);
        gbc.gridx = 1;
        exerciseField = new JTextField(20);
        formPanel.add(exerciseField, gbc);

        // Sets
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Sets:"), gbc);
        gbc.gridx = 1;
        setsField = new JTextField(5);
        formPanel.add(setsField, gbc);

        // Reps
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Reps:"), gbc);
        gbc.gridx = 1;
        repsField = new JTextField(5);
        formPanel.add(repsField, gbc);

        // Instructions
        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(new JLabel("Instructions:"), gbc);
        gbc.gridx = 1;
        instructionsArea = new JTextArea(3, 20);
        instructionsArea.setLineWrap(true);
        instructionsArea.setWrapStyleWord(true);
        formPanel.add(new JScrollPane(instructionsArea), gbc);

        // Timer label
        timerLabel = new JLabel("00:00:00");
        timerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        timerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JPanel timerPanel = new JPanel(new BorderLayout());
        timerPanel.add(timerLabel, BorderLayout.CENTER);
        
        // Initialize rest timer popup
        restTimerDialog = new JDialog(this, "Rest Timer", false);
        restTimerDialog.setSize(300, 150);
        restTimerDialog.setLocationRelativeTo(this);
        restTimerDialog.setLayout(new BorderLayout());
        
        popupTimerLabel = new JLabel("05:00", SwingConstants.CENTER);
        popupTimerLabel.setFont(new Font("Arial", Font.BOLD, 48));
        popupTimerLabel.setForeground(Color.RED);
        
        JButton stopRestButton = new JButton("Stop Rest");
        stopRestButton.addActionListener(e -> {
            restTimer.stop();
            restTimerDialog.setVisible(false);
        });
        
        JPanel popupPanel = new JPanel(new BorderLayout());
        popupPanel.add(popupTimerLabel, BorderLayout.CENTER);
        popupPanel.add(stopRestButton, BorderLayout.SOUTH);
        
        restTimerDialog.add(popupPanel);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("Add Workout");
        JButton deleteButton = new JButton("Delete Workout");
        startButton = new JButton("Start Exercise");
        JButton backToDashboardButton = new JButton("Back to Dashboard");
        
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(startButton);
        buttonPanel.add(backToDashboardButton);

        // Add form and buttons to main panel
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(timerPanel, BorderLayout.SOUTH);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add action listeners
        addButton.addActionListener(e -> addWorkout());
        deleteButton.addActionListener(e -> deleteWorkout());
        startButton.addActionListener(e -> toggleExercise());
        backToDashboardButton.addActionListener(e -> goBackToDashboard());

        // Initialize timers
        exerciseTimer = new Timer(1000, e -> updateTimer());
        restTimer = new Timer(1000, e -> updateRestTimer());

        add(mainPanel);
    }

    private void toggleExercise() {
        int selectedRow = workoutTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select an exercise to start", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        isExerciseInProgress = !isExerciseInProgress;
        if (isExerciseInProgress) {
            startButton.setText("Stop Exercise");
            exerciseTimer.start();
            // Start rest timer
            restSeconds = REST_TIME_MINUTES * 60;
            popupTimerLabel.setText(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60));
            restTimerDialog.setVisible(true);
            restTimer.start();
        } else {
            startButton.setText("Start Exercise");
            exerciseTimer.stop();
            restTimer.stop();
            seconds = 0;
            restSeconds = 0;
            timerLabel.setText("00:00:00");
            restTimerDialog.setVisible(false);
        }
    }

    private void updateTimer() {
        seconds++;
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs = seconds % 60;
        timerLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, secs));
    }

    private void updateRestTimer() {
        if (restSeconds > 0) {
            restSeconds--;
            popupTimerLabel.setText(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60));
        } else {
            restTimer.stop();
            restTimerDialog.setVisible(false);
            JOptionPane.showMessageDialog(this, "Rest time is over! You can continue with your exercise.", "Rest Complete", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void addWorkout() {
        try {
            String day = (String) dayComboBox.getSelectedItem();
            String exercise = exerciseField.getText().trim();
            int sets = Integer.parseInt(setsField.getText().trim());
            int reps = Integer.parseInt(repsField.getText().trim());
            String instructions = instructionsArea.getText().trim();

            if (exercise.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an exercise name", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Workout workout = new Workout(currentUserId, day, exercise, sets, reps, instructions);
            workoutService.saveWorkout(workout);
            workouts = workoutService.getWorkoutsByUserId(currentUserId);
            updateTable();
            clearForm();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for sets and reps", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteWorkout() {
        int selectedRow = workoutTable.getSelectedRow();
        if (selectedRow >= 0) {
            Workout workout = workouts.get(selectedRow);
            workoutService.deleteWorkout(workout.getId());
            workouts = workoutService.getWorkoutsByUserId(currentUserId);
            updateTable();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a workout to delete", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTable() {
        tableModel.setRowCount(0);
        for (Workout workout : workouts) {
            tableModel.addRow(new Object[]{
                workout.getDayOfWeek(),
                workout.getExerciseName(),
                workout.getSets(),
                workout.getReps(),
                workout.getInstructions()
            });
        }
    }

    private void clearForm() {
        exerciseField.setText("");
        setsField.setText("");
        repsField.setText("");
        instructionsArea.setText("");
    }

    private void loadWorkouts() {
        workouts = workoutService.getWorkoutsByUserId(currentUserId);
        updateTable();
    }

    private void goBackToDashboard() {
        this.setVisible(false);
    }
} 