package com.fitmitra.service;

import com.fitmitra.model.Meal;
import com.fitmitra.repository.MealRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class MealService {
    @Autowired
    private MealRepository mealRepository;

    public List<Meal> getPredefinedMeals() {
        return mealRepository.findByIsCustomFalse();
    }

    public List<Meal> getUserMeals(Long userId) {
        return mealRepository.findByUserId(userId);
    }

    public List<Meal> getMealsByDate(Long userId, LocalDate date) {
        return mealRepository.findByUserIdAndConsumedDate(userId, date);
    }

    public List<Meal> getMealsByType(String mealType) {
        return mealRepository.findByMealType(mealType);
    }

    public Meal saveMeal(Meal meal) {
        return mealRepository.save(meal);
    }

    public void deleteMeal(Long id) {
        mealRepository.deleteById(id);
    }

    public Meal addMealToUser(Long userId, Meal meal) {
        Meal newMeal = new Meal();
        newMeal.setName(meal.getName());
        newMeal.setMealType(meal.getMealType());
        newMeal.setCalories(meal.getCalories());
        newMeal.setProtein(meal.getProtein());
        newMeal.setCarbs(meal.getCarbs());
        newMeal.setFats(meal.getFats());
        newMeal.setIngredients(meal.getIngredients());
        newMeal.setIsCustom(false);
        newMeal.setUserId(userId);
        newMeal.setConsumedDate(LocalDate.now());
        return mealRepository.save(newMeal);
    }

    public Meal saveCustomMeal(Long userId, Meal meal) {
        meal.setUserId(userId);
        meal.setIsCustom(true);
        meal.setConsumedDate(LocalDate.now());
        return mealRepository.save(meal);
    }
} 