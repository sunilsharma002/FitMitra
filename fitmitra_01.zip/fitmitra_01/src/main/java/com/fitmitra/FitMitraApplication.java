package com.fitmitra;

import com.fitmitra.ui.LoginFrame;
import com.formdev.flatlaf.FlatDarkLaf;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import javax.swing.*;

@SpringBootApplication
public class FitMitraApplication {
    public static void main(String[] args) {
        // Set the dark theme
        FlatDarkLaf.setup();
        
        // Create and configure the Spring application context
        ConfigurableApplicationContext context = new SpringApplicationBuilder(FitMitraApplication.class)
                .headless(false)
                .run(args);
        
        // Start the application in the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            // Initialize and show the login frame
            LoginFrame loginFrame = context.getBean(LoginFrame.class);
            loginFrame.setVisible(true);
        });
    }
} 