package com.fitmitra.repository;

import com.fitmitra.model.Workout;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkoutRepository extends JpaRepository<Workout, Long> {
    List<Workout> findByUserId(Long userId);
    List<Workout> findByUserIdOrderByDayOfWeekAscExerciseNameAsc(Long userId);
    
    @Query("SELECT COUNT(DISTINCT w.dayOfWeek) FROM Workout w WHERE w.userId = ?1")
    Long countDistinctDaysByUserId(Long userId);
    
    @Query("SELECT w.exerciseName, COUNT(w) as count FROM Workout w WHERE w.userId = ?1 GROUP BY w.exerciseName ORDER BY count DESC")
    List<Object[]> findMostFrequentExerciseByUserId(Long userId);
}
