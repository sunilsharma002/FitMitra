package com.fitmitra.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.json.JSONArray;

public class ChatBot extends javax.swing.JFrame {
    private javax.swing.JTextField inputField;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton sendButton;
    private javax.swing.JButton backButton;
    private Map<String, String> responses;

    public ChatBot() {
        initComponents();
        setLocationRelativeTo(null);
        
        // Initialize predefined responses
        responses = new HashMap<>();
        responses.put("hello", "Hi there! I'm your fitness assistant. How can I help you with your fitness goals today?");
        responses.put("hi", "Hello! I'm here to help you with fitness, diet, and wellness. What would you like to know?");
        responses.put("help", "I can help you with:\n- Workout routines and exercises\n- Diet and nutrition advice\n- Fitness goals and planning\n- Health and wellness tips\n- Exercise form and technique\nJust ask me anything fitness-related!");
        responses.put("bye", "Goodbye! Keep up your fitness journey!");
        responses.put("thanks", "You're welcome! Stay motivated and keep working towards your fitness goals!");
        responses.put("thank you", "You're welcome! Stay motivated and keep working towards your fitness goals!");
        responses.put("how are you", "I'm doing great! Ready to help you achieve your fitness goals!");
        responses.put("what can you do", "I can help you with:\n- Workout routines and exercises\n- Diet and nutrition advice\n- Fitness goals and planning\n- Health and wellness tips\n- Exercise form and technique\nJust ask me anything fitness-related!");
        responses.put("fitness", "I can help you with various aspects of fitness:\n- Workout plans\n- Exercise techniques\n- Diet advice\n- Health tips\nWhat specific area would you like to know more about?");
        responses.put("diet", "I can help you with diet and nutrition advice. Would you like to know about:\n- Healthy meal plans\n- Nutrition tips\n- Diet for specific goals\n- Supplements\nWhat would you like to learn?");
        responses.put("workout", "I can help you with workout routines. Would you like to know about:\n- Strength training\n- Cardio exercises\n- HIIT workouts\n- Yoga and stretching\nWhat type of workout interests you?");
        
        // Add action listener for Enter key
        inputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    sendMessage();
                }
            }
        });
    }

    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        inputField = new javax.swing.JTextField();
        sendButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Your Friend - ChatBot");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setEditable(false);
        jScrollPane1.setViewportView(jTextArea1);

        inputField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        inputField.addActionListener(evt -> inputFieldActionPerformed(evt));

        sendButton.setBackground(new java.awt.Color(255, 255, 153));
        sendButton.setForeground(new java.awt.Color(153, 0, 0));
        sendButton.setText("Send");
        sendButton.addActionListener(evt -> sendButtonActionPerformed(evt));

        backButton.setBackground(new java.awt.Color(200, 200, 200));
        backButton.setForeground(new java.awt.Color(0, 100, 100));
        backButton.setText("Back to Dashboard");
        backButton.addActionListener(evt -> this.dispose());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane1)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(inputField, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(sendButton, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE))
                .addComponent(backButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(inputField)
                        .addComponent(sendButton, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        inputField.getAccessibleContext().setAccessibleName("");
        pack();
    }

    private void sendMessage() {
        String userText = inputField.getText().trim();
        if (!userText.isEmpty()) {
            // Disable input while processing to prevent multiple requests
            inputField.setEnabled(false);
            sendButton.setEnabled(false);
            
            jTextArea1.append("You: " + userText + "\n");
            inputField.setText("");
            
            // Check for predefined responses first
            String predefinedResponse = responses.get(userText.toLowerCase());
            if (predefinedResponse != null) {
                jTextArea1.append("Bot: " + predefinedResponse + "\n\n");
                jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
                // Re-enable input
                inputField.setEnabled(true);
                sendButton.setEnabled(true);
                inputField.requestFocus();
                return;
            }
            
            // Show loading message
            jTextArea1.append("Bot is thinking...\n");
            jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
            
            // Create a new thread for API call
            new Thread(() -> {
                try {
                    String botReply = getAIResponse(userText);
                    SwingUtilities.invokeLater(() -> {
                        // Remove "Bot is thinking..." message
                        String currentText = jTextArea1.getText();
                        int lastIndex = currentText.lastIndexOf("Bot is thinking...\n");
                        if (lastIndex != -1) {
                            jTextArea1.setText(currentText.substring(0, lastIndex));
                        }
                        // Add the response
                        jTextArea1.append("Bot: " + botReply + "\n\n");
                        jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
                        // Re-enable input
                        inputField.setEnabled(true);
                        sendButton.setEnabled(true);
                        inputField.requestFocus();
                    });
                } catch (Exception e) {
                    SwingUtilities.invokeLater(() -> {
                        // Remove "Bot is thinking..." message
                        String currentText = jTextArea1.getText();
                        int lastIndex = currentText.lastIndexOf("Bot is thinking...\n");
                        if (lastIndex != -1) {
                            jTextArea1.setText(currentText.substring(0, lastIndex));
                        }
                        // Add error message
                        jTextArea1.append("Bot: Connection is taking too long. Please check your internet connection and try again.\n\n");
                        jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
                        // Re-enable input
                        inputField.setEnabled(true);
                        sendButton.setEnabled(true);
                        inputField.requestFocus();
                    });
                }
            }).start();
        }
    }

    private String getAIResponse(String userMessage) {
        try {
            URL url = new URL("https://openrouter.ai/api/v1/chat/completions");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer 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");
            conn.setRequestProperty("HTTP-Referer", "https://github.com/fitmitra");
            conn.setRequestProperty("X-Title", "FitMitra");
            conn.setDoOutput(true);
            
            // Set reasonable timeouts for slow connections
            conn.setConnectTimeout(15000);  // 15 seconds to establish connection
            conn.setReadTimeout(30000);     // 30 seconds to read response

            JSONObject requestBody = new JSONObject();
            requestBody.put("model", "deepseek/deepseek-r1:free");
            
            JSONArray messages = new JSONArray();
            JSONObject message = new JSONObject();
            message.put("role", "user");
            message.put("content", userMessage);
            messages.put(message);
            
            requestBody.put("messages", messages);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = requestBody.toString().getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                
                JSONObject jsonResponse = new JSONObject(response.toString());
                return jsonResponse.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content");
            }
        } catch (java.net.SocketTimeoutException e) {
            return "Connection is taking too long. Please check your internet connection and try again.";
        } catch (Exception e) {
            e.printStackTrace();
            return "Sorry, I encountered an error. Please check your internet connection and try again.";
        }
    }

    private void inputFieldActionPerformed(java.awt.event.ActionEvent evt) {
        sendMessage();
    }

    private void sendButtonActionPerformed(java.awt.event.ActionEvent evt) {
        sendMessage();
    }
} 