-- FitMitra Database Schema
-- Create database if not exists
CREATE DATABASE IF NOT EXISTS fitmitra_01;
USE fitmitra_01;

-- Drop existing tables if they exist (for clean setup)
DROP TABLE IF EXISTS daily_tracking;
DROP TABLE IF EXISTS goals;
DROP TABLE IF EXISTS meals;
DROP TABLE IF EXISTS workouts;
DROP TABLE IF EXISTS users;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    height DOUBLE NOT NULL,
    weight DOUBLE NOT NULL,
    fitness_aim VARCHAR(50) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert test user (username: test, password: test)
INSERT INTO users (full_name, username, password, age, height, weight, fitness_aim, gender)
VALUES ('Test User', 'test', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 25, 175, 75, 'Weight Loss', 'Male')
ON DUPLICATE KEY UPDATE id=id;

-- Workouts table
CREATE TABLE IF NOT EXISTS workouts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    day_of_week VARCHAR(10) NOT NULL,
    exercise_name VARCHAR(100) NOT NULL,
    sets INT NOT NULL,
    reps INT NOT NULL,
    instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert sample workouts for test user
INSERT INTO workouts (user_id, day_of_week, exercise_name, sets, reps, instructions) VALUES
(1, 'Monday', 'Push-ups', 3, 15, 'Keep your back straight and lower your body until your chest nearly touches the floor'),
(1, 'Monday', 'Squats', 4, 12, 'Keep your back straight and lower your body until your thighs are parallel to the floor'),
(1, 'Monday', 'Plank', 3, 60, 'Hold plank position for 60 seconds'),
(1, 'Wednesday', 'Pull-ups', 3, 10, 'Pull your body up until your chin is above the bar'),
(1, 'Wednesday', 'Lunges', 3, 12, 'Step forward and lower your body until both knees are bent at 90 degrees'),
(1, 'Wednesday', 'Bicycle Crunches', 3, 20, 'Alternate bringing opposite elbow to knee'),
(1, 'Friday', 'Deadlifts', 4, 8, 'Keep your back straight and lift the weight using your legs and back'),
(1, 'Friday', 'Bench Press', 4, 10, 'Lower the bar to your chest and press back up'),
(1, 'Friday', 'Shoulder Press', 3, 12, 'Press weights overhead from shoulder level')
ON DUPLICATE KEY UPDATE id=id;

-- Meals table
CREATE TABLE IF NOT EXISTS meals (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    meal_type VARCHAR(50) NOT NULL,
    calories DOUBLE NOT NULL,
    protein DOUBLE NOT NULL,
    carbs DOUBLE NOT NULL,
    fats DOUBLE NOT NULL,
    ingredients TEXT,
    is_custom BOOLEAN DEFAULT FALSE,
    consumed_date DATE,
    user_id BIGINT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);



-- Goals table
CREATE TABLE IF NOT EXISTS goals (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    target_weight DOUBLE,
    target_date DATE,
    start_date DATE,
    end_date DATE,
    status VARCHAR(20) DEFAULT 'NOT_STARTED',
    user_id BIGINT,
    is_predefined BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Drop the user_goals table since we've merged it into the goals table
DROP TABLE IF EXISTS user_goals;

-- Remove old predefined goals
DELETE FROM goals WHERE is_predefined = TRUE;

-- Insert new predefined goals
INSERT INTO goals (name, description, target_weight, target_date, status, is_predefined)
VALUES 
('Weight Loss - Beginner', 'Lose 5kg in 3 months with a balanced diet and regular exercise', 5.0, DATE_ADD(CURRENT_DATE, INTERVAL 3 MONTH), 'NOT_STARTED', true),
('Weight Loss - Intermediate', 'Lose 10kg in 6 months with advanced workout routines', 10.0, DATE_ADD(CURRENT_DATE, INTERVAL 6 MONTH), 'NOT_STARTED', true),
('Muscle Gain - Beginner', 'Gain 3kg of muscle mass in 4 months with strength training', 3.0, DATE_ADD(CURRENT_DATE, INTERVAL 4 MONTH), 'NOT_STARTED', true),
('Muscle Gain - Advanced', 'Gain 5kg of muscle mass in 6 months with intensive training', 5.0, DATE_ADD(CURRENT_DATE, INTERVAL 6 MONTH), 'NOT_STARTED', true),
('Fitness Maintenance', 'Maintain current weight and improve overall fitness', 0.0, DATE_ADD(CURRENT_DATE, INTERVAL 12 MONTH), 'NOT_STARTED', true),
('Flexibility Improvement', 'Improve flexibility and mobility through yoga and stretching', 0.0, DATE_ADD(CURRENT_DATE, INTERVAL 3 MONTH), 'NOT_STARTED', true),
('Cardio Endurance', 'Build cardiovascular endurance through regular cardio exercises', 0.0, DATE_ADD(CURRENT_DATE, INTERVAL 4 MONTH), 'NOT_STARTED', true),
('Body Recomposition', 'Reduce body fat while maintaining muscle mass', 0.0, DATE_ADD(CURRENT_DATE, INTERVAL 6 MONTH), 'NOT_STARTED', true);

-- Insert some predefined meals
INSERT INTO meals (name, meal_type, calories, protein, carbs, fats, ingredients, is_custom) VALUES
('Chicken Breast', 'Lunch', 165, 31, 0, 3.6, 'Grilled chicken breast', FALSE),
('Brown Rice', 'Lunch', 216, 4.5, 45, 1.8, 'Cooked brown rice', FALSE),
('Broccoli', 'Lunch', 55, 3.7, 11.2, 0.6, 'Steamed broccoli', FALSE),
('Salmon', 'Dinner', 206, 22, 0, 13, 'Grilled salmon fillet', FALSE),
('Oatmeal', 'Breakfast', 150, 5, 27, 3, 'Plain oatmeal', FALSE),
('Greek Yogurt', 'Breakfast', 100, 10, 6, 4, 'Plain Greek yogurt', FALSE),
('Eggs', 'Breakfast', 155, 13, 1.1, 11, 'Scrambled eggs (2 eggs)', FALSE),
('Sweet Potato', 'Lunch', 112, 2, 26, 0.1, 'Baked sweet potato', FALSE),
('Almonds', 'Snack', 164, 6, 6, 14, 'Raw almonds (28g)', FALSE),
('Protein Shake', 'Snack', 120, 24, 3, 1.5, 'Whey protein shake', FALSE);

-- Daily tracking table for water, calories, and steps
CREATE TABLE IF NOT EXISTS daily_tracking (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    date DATE NOT NULL,
    water_intake_ml INT DEFAULT 0,
    calories_consumed INT DEFAULT 0,
    steps_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE KEY unique_user_date (user_id, date)
);

-- Insert sample data for the last 7 days for all users
INSERT INTO daily_tracking (user_id, date, water_intake_ml, calories_consumed, steps_count)
SELECT 
    u.id as user_id,
    DATE_SUB(CURRENT_DATE, INTERVAL n.n DAY) as date,
    2000 + (RAND() * 1000) as water_intake_ml,
    1800 + (RAND() * 500) as calories_consumed,
    8000 + (RAND() * 2000) as steps_count
FROM users u
CROSS JOIN (
    SELECT 0 as n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 
    UNION SELECT 4 UNION SELECT 5 UNION SELECT 6
) n
WHERE NOT EXISTS (
    SELECT 1 FROM daily_tracking dt 
    WHERE dt.user_id = u.id 
    AND dt.date = DATE_SUB(CURRENT_DATE, INTERVAL n.n DAY)
);

-- Insert today's data if not exists
INSERT INTO daily_tracking (user_id, date, water_intake_ml, calories_consumed, steps_count)
SELECT 
    id as user_id,
    CURRENT_DATE as date,
    2000 as water_intake_ml,
    2000 as calories_consumed,
    8000 as steps_count
FROM users
WHERE NOT EXISTS (
    SELECT 1 FROM daily_tracking 
    WHERE user_id = users.id 
    AND date = CURRENT_DATE
); 