package com.fitmitra.ui;

import com.fitmitra.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;

import javax.swing.*;
import java.awt.*;

@Component
public class ProfileFrame extends JFrame {
    private Long currentUserId;
    private JTextField fullNameField;
    private JTextField usernameField;
    private JTextField ageField;
    private JTextField heightField;
    private JTextField weightField;
    private JComboBox<String> genderCombo;
    private JComboBox<String> fitnessAimCombo;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public ProfileFrame() {
        // Empty constructor for Spring
    }

    @PostConstruct
    private void init() {
        initializeUI();
    }

    private void initializeUI() {
        setTitle("FitMitra - User Profile");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Main panel with dark theme
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(45, 45, 45));
        mainPanel.setLayout(new BorderLayout(20, 20));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(45, 45, 45));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Create form fields
        fullNameField = createStyledTextField("Full Name");
        usernameField = createStyledTextField("Username");
        usernameField.setEditable(false); // Username cannot be changed
        ageField = createStyledTextField("Age");
        heightField = createStyledTextField("Height (cm)");
        weightField = createStyledTextField("Weight (kg)");
        genderCombo = new JComboBox<>(new String[]{"Male", "Female"});
        fitnessAimCombo = new JComboBox<>(new String[]{
            "Mass Gain", "Weight Loss", "Maintenance", "Endurance", "Strength"
        });

        // Style the combo boxes
        styleComboBox(genderCombo);
        styleComboBox(fitnessAimCombo);

        // Add components to form
        addFormRow(formPanel, "Full Name:", fullNameField, gbc, 0);
        addFormRow(formPanel, "Username:", usernameField, gbc, 1);
        addFormRow(formPanel, "Age:", ageField, gbc, 2);
        addFormRow(formPanel, "Height:", heightField, gbc, 3);
        addFormRow(formPanel, "Weight:", weightField, gbc, 4);
        addFormRow(formPanel, "Gender:", genderCombo, gbc, 5);
        addFormRow(formPanel, "Fitness Aim:", fitnessAimCombo, gbc, 6);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonsPanel.setBackground(new Color(45, 45, 45));

        JButton saveButton = createStyledButton("Save Changes");
        JButton backButton = createStyledButton("Back to Dashboard");

        saveButton.addActionListener(e -> saveProfile());
        backButton.addActionListener(e -> dispose());

        buttonsPanel.add(saveButton);
        buttonsPanel.add(backButton);

        // Add all panels to main panel
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JTextField createStyledTextField(String placeholder) {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBackground(new Color(60, 60, 60));
        return field;
    }

    private void styleComboBox(JComboBox<String> comboBox) {
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        comboBox.setForeground(Color.WHITE);
        comboBox.setBackground(new Color(60, 60, 60));
        comboBox.setBorder(BorderFactory.createLineBorder(Color.WHITE));
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(52, 152, 219));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }

    private void addFormRow(JPanel panel, String labelText, JComponent field, GridBagConstraints gbc, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panel.add(field, gbc);
        gbc.weightx = 0.0;
    }

    public void setUserId(Long userId) {
        this.currentUserId = userId;
        loadUserProfile();
    }

    private void loadUserProfile() {
        try {
            String sql = "SELECT full_name, username, age, height, weight, gender, fitness_aim " +
                        "FROM users WHERE id = ?";
            
            var userData = jdbcTemplate.queryForMap(sql, currentUserId);

            fullNameField.setText(String.valueOf(userData.get("full_name")));
            usernameField.setText(String.valueOf(userData.get("username")));
            ageField.setText(String.valueOf(userData.get("age")));
            heightField.setText(String.valueOf(userData.get("height")));
            weightField.setText(String.valueOf(userData.get("weight")));
            genderCombo.setSelectedItem(String.valueOf(userData.get("gender")));
            fitnessAimCombo.setSelectedItem(String.valueOf(userData.get("fitness_aim")));
            
            setTitle("FitMitra - " + userData.get("full_name") + "'s Profile");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error loading profile data: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveProfile() {
        try {
            String sql = "UPDATE users SET " +
                        "full_name = ?, age = ?, height = ?, weight = ?, " +
                        "gender = ?, fitness_aim = ? " +
                        "WHERE id = ?";

            jdbcTemplate.update(sql,
                fullNameField.getText(),
                Integer.parseInt(ageField.getText()),
                Double.parseDouble(heightField.getText()),
                Double.parseDouble(weightField.getText()),
                genderCombo.getSelectedItem(),
                fitnessAimCombo.getSelectedItem(),
                currentUserId
            );

            JOptionPane.showMessageDialog(this,
                "Profile updated successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
                
            dispose();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error saving profile: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
} 