package com.fitmitra.ui;

import com.fitmitra.model.Meal;
import com.fitmitra.service.MealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTabbedPane;
import javax.swing.JOptionPane;
import javax.swing.JDialog;
import javax.swing.BorderFactory;
import javax.swing.table.DefaultTableModel;
import java.util.List;

@Component
public class NutritionFrame extends JFrame {
    private JTable mealTable;
    private JTable myMealsTable;
    private DefaultTableModel tableModel;
    private DefaultTableModel myMealsModel;
    private List<Meal> meals;
    private Long currentUserId;
    
    @Autowired
    private MealService mealService;

    public NutritionFrame() {
        // Empty constructor for Spring
    }

    @PostConstruct
    private void init() {
        initializeUI();
    }

    public void setUserId(Long userId) {
        this.currentUserId = userId;
        loadMeals();
    }

    private void initializeUI() {
        setTitle("FitMitra - Nutrition Management");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // Pre-defined Meals Tab
        JPanel predefinedPanel = createPredefinedMealsPanel();
        tabbedPane.addTab("Pre-defined Meals", predefinedPanel);

        // Custom Meals Tab
        JPanel customPanel = createCustomMealsPanel();
        tabbedPane.addTab("Custom Meals", customPanel);

        // My Meals Tab
        JPanel myMealsPanel = createMyMealsPanel();
        tabbedPane.addTab("My Meals", myMealsPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        add(mainPanel);
    }

    private JPanel createPredefinedMealsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Table for predefined meals
        String[] columnNames = {"Meal Type", "Name", "Calories", "Protein (g)", "Carbs (g)", "Fats (g)"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        mealTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(mealTable);
        panel.add(tableScrollPane, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addToMyMealsButton = new JButton("Add to My Meals");
        JButton viewDetailsButton = new JButton("View Details");
        JButton backButton = new JButton("Back to Dashboard");

        addToMyMealsButton.addActionListener(e -> addToMyMeals());
        viewDetailsButton.addActionListener(e -> viewMealDetails());
        backButton.addActionListener(e -> goBackToDashboard());

        buttonPanel.add(addToMyMealsButton);
        buttonPanel.add(viewDetailsButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createCustomMealsPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Meal Type
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Meal Type:"), gbc);
        gbc.gridx = 1;
        String[] mealTypes = {"Breakfast", "Lunch", "Dinner", "Snack"};
        JComboBox<String> mealTypeCombo = new JComboBox<>(mealTypes);
        panel.add(mealTypeCombo, gbc);

        // Meal Name
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Meal Name:"), gbc);
        gbc.gridx = 1;
        JTextField mealNameField = new JTextField(20);
        panel.add(mealNameField, gbc);

        // Ingredients
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Ingredients:"), gbc);
        gbc.gridx = 1;
        JTextArea ingredientsArea = new JTextArea(3, 20);
        ingredientsArea.setLineWrap(true);
        panel.add(new JScrollPane(ingredientsArea), gbc);

        // Nutrition Values
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Calories:"), gbc);
        gbc.gridx = 1;
        JTextField caloriesField = new JTextField(10);
        panel.add(caloriesField, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(new JLabel("Protein (g):"), gbc);
        gbc.gridx = 1;
        JTextField proteinField = new JTextField(10);
        panel.add(proteinField, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        panel.add(new JLabel("Carbs (g):"), gbc);
        gbc.gridx = 1;
        JTextField carbsField = new JTextField(10);
        panel.add(carbsField, gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        panel.add(new JLabel("Fats (g):"), gbc);
        gbc.gridx = 1;
        JTextField fatsField = new JTextField(10);
        panel.add(fatsField, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save Meal");
        JButton backButton = new JButton("Back to Dashboard");

        saveButton.addActionListener(e -> saveCustomMeal(
            (String) mealTypeCombo.getSelectedItem(),
            mealNameField.getText(),
            ingredientsArea.getText(),
            caloriesField.getText(),
            proteinField.getText(),
            carbsField.getText(),
            fatsField.getText()
        ));
        backButton.addActionListener(e -> goBackToDashboard());

        buttonPanel.add(saveButton);
        buttonPanel.add(backButton);
        gbc.gridx = 0; gbc.gridy = 7;
        gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);

        return panel;
    }

    private JPanel createMyMealsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Table for user's meals
        String[] columnNames = {"Date", "Meal Type", "Name", "Calories", "Protein (g)", "Carbs (g)", "Fats (g)"};
        myMealsModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        myMealsTable = new JTable(myMealsModel);
        JScrollPane tableScrollPane = new JScrollPane(myMealsTable);
        panel.add(tableScrollPane, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addMealButton = new JButton("Add Meal to Today");
        JButton viewHistoryButton = new JButton("View History");
        JButton backButton = new JButton("Back to Dashboard");

        addMealButton.addActionListener(e -> addMealToToday());
        viewHistoryButton.addActionListener(e -> viewMealHistory());
        backButton.addActionListener(e -> goBackToDashboard());

        buttonPanel.add(addMealButton);
        buttonPanel.add(viewHistoryButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadMeals() {
        // Load predefined meals
        List<Meal> predefinedMeals = mealService.getPredefinedMeals();
        updateTable(predefinedMeals);

        // Load user's meals in the My Meals tab
        List<Meal> userMeals = mealService.getUserMeals(currentUserId);
        updateMyMealsTable(userMeals);
    }

    private void updateTable(List<Meal> meals) {
        tableModel.setRowCount(0);
        for (Meal meal : meals) {
            tableModel.addRow(new Object[]{
                meal.getMealType(),
                meal.getName(),
                meal.getCalories(),
                meal.getProtein(),
                meal.getCarbs(),
                meal.getFats()
            });
        }
    }

    private void updateMyMealsTable(List<Meal> meals) {
        myMealsModel.setRowCount(0);

        for (Meal meal : meals) {
            myMealsModel.addRow(new Object[]{
                meal.getConsumedDate(),
                meal.getMealType(),
                meal.getName(),
                meal.getCalories(),
                meal.getProtein(),
                meal.getCarbs(),
                meal.getFats()
            });
        }
    }

    private void addToMyMeals() {
        int selectedRow = mealTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Please select a meal to add",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Get the selected meal's data
            String mealType = String.valueOf(tableModel.getValueAt(selectedRow, 0));
            String name = String.valueOf(tableModel.getValueAt(selectedRow, 1));
            
            // Handle numeric values properly
            double calories = Double.parseDouble(String.valueOf(tableModel.getValueAt(selectedRow, 2)));
            double protein = Double.parseDouble(String.valueOf(tableModel.getValueAt(selectedRow, 3)));
            double carbs = Double.parseDouble(String.valueOf(tableModel.getValueAt(selectedRow, 4)));
            double fats = Double.parseDouble(String.valueOf(tableModel.getValueAt(selectedRow, 5)));

            // Create a new meal object
            Meal meal = new Meal();
            meal.setMealType(mealType);
            meal.setName(name);
            meal.setCalories(calories);
            meal.setProtein(protein);
            meal.setCarbs(carbs);
            meal.setFats(fats);
            meal.setIsCustom(false);

            // Add the meal to user's meals
            mealService.addMealToUser(currentUserId, meal);

            // Show success message
            JOptionPane.showMessageDialog(this,
                "Meal added to your meals successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);

            // Refresh the meals list
            loadMeals();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error adding meal: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // This will help with debugging
        }
    }

    private void viewMealDetails() {
        int selectedRow = mealTable.getSelectedRow();
        if (selectedRow >= 0) {
            Meal selectedMeal = meals.get(selectedRow);
            showMealDetails(selectedMeal);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a meal first", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showMealDetails(Meal meal) {
        JDialog detailsDialog = new JDialog(this, "Meal Details", true);
        detailsDialog.setSize(400, 300);
        detailsDialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Name: " + meal.getName()), gbc);
        gbc.gridy++;
        panel.add(new JLabel("Type: " + meal.getMealType()), gbc);
        gbc.gridy++;
        panel.add(new JLabel("Ingredients:"), gbc);
        gbc.gridy++;
        JTextArea ingredientsArea = new JTextArea(meal.getIngredients());
        ingredientsArea.setEditable(false);
        ingredientsArea.setLineWrap(true);
        panel.add(new JScrollPane(ingredientsArea), gbc);
        gbc.gridy++;
        panel.add(new JLabel("Calories: " + meal.getCalories()), gbc);
        gbc.gridy++;
        panel.add(new JLabel("Protein: " + meal.getProtein() + "g"), gbc);
        gbc.gridy++;
        panel.add(new JLabel("Carbs: " + meal.getCarbs() + "g"), gbc);
        gbc.gridy++;
        panel.add(new JLabel("Fats: " + meal.getFats() + "g"), gbc);

        detailsDialog.add(panel);
        detailsDialog.setVisible(true);
    }

    private void saveCustomMeal(String mealType, String name, String ingredients, 
                              String calories, String protein, String carbs, String fats) {
        try {
            Meal meal = new Meal();
            meal.setMealType(mealType);
            meal.setName(name);
            meal.setIngredients(ingredients);
            meal.setCalories(Double.parseDouble(calories));
            meal.setProtein(Double.parseDouble(protein));
            meal.setCarbs(Double.parseDouble(carbs));
            meal.setFats(Double.parseDouble(fats));
            
            mealService.saveCustomMeal(currentUserId, meal);
            JOptionPane.showMessageDialog(this, "Custom meal saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for nutrition values", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addMealToToday() {
        // TODO: Implement adding meal to today's plan
    }

    private void viewMealHistory() {
        // TODO: Implement meal history view
    }

    private void goBackToDashboard() {
        this.setVisible(false);
    }
} 