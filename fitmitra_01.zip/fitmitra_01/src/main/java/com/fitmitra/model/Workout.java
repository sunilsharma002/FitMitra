package com.fitmitra.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "workouts")
public class Workout {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id", nullable = false)
    private Long userId;
    
    @Column(name = "day_of_week", nullable = false)
    private String dayOfWeek;
    
    @Column(name = "exercise_name", nullable = false)
    private String exerciseName;
    
    @Column(nullable = false)
    private int sets;
    
    @Column(nullable = false)
    private int reps;
    
    @Column(columnDefinition = "TEXT")
    private String instructions;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Workout() {}

    public Workout(Long userId, String dayOfWeek, String exerciseName, int sets, int reps, String instructions) {
        this.userId = userId;
        this.dayOfWeek = dayOfWeek;
        this.exerciseName = exerciseName;
        this.sets = sets;
        this.reps = reps;
        this.instructions = instructions;
    }
} 