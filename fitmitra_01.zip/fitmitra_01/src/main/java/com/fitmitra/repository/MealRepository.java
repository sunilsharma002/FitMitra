package com.fitmitra.repository;

import com.fitmitra.model.Meal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface MealRepository extends JpaRepository<Meal, Long> {
    List<Meal> findByIsCustomFalse();
    List<Meal> findByUserId(Long userId);
    List<Meal> findByUserIdAndConsumedDate(Long userId, LocalDate date);
    List<Meal> findByMealType(String mealType);
} 