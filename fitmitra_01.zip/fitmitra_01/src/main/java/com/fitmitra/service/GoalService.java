package com.fitmitra.service;

import com.fitmitra.model.Goal;
import com.fitmitra.repository.GoalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class GoalService {
    @Autowired
    private GoalRepository goalRepository;

    public List<Goal> getPredefinedGoals() {
        return goalRepository.findByIsPredefined(true);
    }

    public List<Goal> getUserGoals(Long userId) {
        return goalRepository.findByUserId(userId);
    }

    public Goal getActiveGoal(Long userId) {
        return goalRepository.findByUserIdAndStatus(userId, "IN_PROGRESS");
    }

    public void addGoalToUser(Long userId, Goal goal) {
        goal.setUserId(userId);
        goal.setIsPredefined(false);
        goal.setStatus("IN_PROGRESS");
        goal.setStartDate(LocalDate.now());
        goalRepository.save(goal);
    }

    public void markGoalComplete(Long userId, String goalName) {
        Goal goal = goalRepository.findByUserIdAndName(userId, goalName);
        if (goal != null) {
            goal.setStatus("COMPLETED");
            goal.setEndDate(LocalDate.now());
            goalRepository.save(goal);
        }
    }

    public void createPredefinedGoal(Goal goal) {
        goal.setIsPredefined(true);
        goal.setStatus("ACTIVE");
        goalRepository.save(goal);
    }
} 