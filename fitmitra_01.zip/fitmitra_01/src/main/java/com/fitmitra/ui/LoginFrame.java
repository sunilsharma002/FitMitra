package com.fitmitra.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.context.ApplicationContext;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.Map;

@Component
public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private ApplicationContext applicationContext;
    
    public LoginFrame() {
        setTitle("FitMitra - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Create main panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(45, 45, 45);
                Color color2 = new Color(30, 30, 30);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Create logo panel
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw logo text
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 36));
                String text = "FitMitra";
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(text)) / 2;
                int y = (getHeight() + fm.getAscent()) / 2;
                g2d.drawString(text, x, y);
                
                // Draw underline
                g2d.setStroke(new BasicStroke(3));
                g2d.drawLine(x, y + 5, x + fm.stringWidth(text), y + 5);
            }
        };
        logoPanel.setPreferredSize(new Dimension(300, 150));
        logoPanel.setOpaque(false);
        
        // Create welcome message panel
        JPanel welcomePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        welcomePanel.setOpaque(false);
        JLabel welcomeLabel = new JLabel("Welcome back to FitMitra - Your Personal Fitness Companion");
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomePanel.add(welcomeLabel);
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Add form fields
        addFormField(formPanel, gbc, "Username:", usernameField = createStyledTextField());
        addFormField(formPanel, gbc, "Password:", passwordField = createStyledPasswordField());
        
        // Add login button
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton loginButton = createStyledButton("Login");
        loginButton.addActionListener(e -> handleLogin());
        formPanel.add(loginButton, gbc);
        
        // Add register button
        gbc.gridy++;
        JButton registerButton = createStyledButton("Create New Account");
        registerButton.addActionListener(e -> goToRegister());
        formPanel.add(registerButton, gbc);
        
        // Add panels to main panel
        mainPanel.add(logoPanel, BorderLayout.NORTH);
        mainPanel.add(welcomePanel, BorderLayout.CENTER);
        mainPanel.add(formPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private void addFormField(JPanel panel, GridBagConstraints gbc, String labelText, JComponent field) {
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.WHITE);
        panel.add(label, gbc);
        
        gbc.gridx = 1;
        panel.add(field, gbc);
    }
    
    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setBackground(new Color(60, 60, 60));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80)));
        return field;
    }
    
    private JPasswordField createStyledPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setBackground(new Color(60, 60, 60));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80)));
        return field;
    }
    
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 150, 136));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }
    
    private void handleLogin() {
        try {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Please enter both username and password.",
                    "Login Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Test database connection first
            try {
                jdbcTemplate.execute("SELECT 1");
                System.out.println("Database connection successful");
            } catch (Exception e) {
                System.out.println("Database connection failed: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Database connection error. Please try again later.",
                    "Connection Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Hash the password
            String hashedPassword = hashPassword(password);
            System.out.println("Password hashed successfully");
            
            // Check if user exists and get their details in one query
            String sql = "SELECT id, username, password FROM users WHERE username = ?";
            try {
                Map<String, Object> user = jdbcTemplate.queryForMap(sql, username);
                
                if (user != null) {
                    String storedHash = (String) user.get("password");
                    
                    if (hashedPassword.equals(storedHash)) {
                        Long userId = (Long) user.get("id");
                        String userUsername = (String) user.get("username");
                        
                        System.out.println("Login successful for user: " + userUsername + " (ID: " + userId + ")");
                        
                        this.setVisible(false);
                        DashboardFrame dashboardFrame = applicationContext.getBean(DashboardFrame.class);
                        dashboardFrame.setCurrentUser(userId, userUsername);
                        dashboardFrame.updateDashboard();
                        dashboardFrame.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Incorrect password. Please try again.",
                            "Login Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (Exception e) {
                System.out.println("Login error: " + e.getMessage());
                if (e.getMessage().contains("Incorrect result size")) {
                    JOptionPane.showMessageDialog(this,
                        "Username not found. Please check your username or register a new account.",
                        "Login Error",
                        JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this,
                        "An error occurred during login. Please try again.",
                        "Login Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "An unexpected error occurred. Please try again.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String hashPassword(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
    
    private void goToRegister() {
        this.setVisible(false);
        RegisterFrame registerFrame = applicationContext.getBean(RegisterFrame.class);
        registerFrame.clearFields();
        registerFrame.setVisible(true);
    }
    
    public void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
    }
} 