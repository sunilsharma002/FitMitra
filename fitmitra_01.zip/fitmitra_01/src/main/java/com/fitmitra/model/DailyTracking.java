package com.fitmitra.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "daily_tracking", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"user_id", "date"})
})
public class DailyTracking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id", nullable = false)
    private Long userId;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(name = "water_intake_ml")
    private Integer waterIntakeMl = 0;
    
    @Column(name = "calories_consumed")
    private Integer caloriesConsumed = 0;
    
    @Column(name = "steps_count")
    private Integer stepsCount = 0;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
